__name__ = "Suluoya"
__author__ = 'Suluoya'
__all__ = ['svg_charts', 'html_charts', 'cute_charts', ]

from .svg_charts import *
from .html_charts import *
from .cute_charts import *
import pretty_errors