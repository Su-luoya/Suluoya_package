__name__ = "Suluoya"
__author__ = 'Suluoya'
__all__ = ['SlyImport']
from .SlyImport import *
import pretty_errors


