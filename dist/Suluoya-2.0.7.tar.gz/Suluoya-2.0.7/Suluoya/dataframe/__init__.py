__name__ = "Suluoya"
__author__ = 'Suluoya'
__all__ = ['SlyDataFrame']
from .SlyDataFrame import *
import pretty_errors