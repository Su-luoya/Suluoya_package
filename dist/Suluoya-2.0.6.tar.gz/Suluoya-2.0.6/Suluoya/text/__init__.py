__name__ = "Suluoya"
__author__ = 'Suluoya'
__all__ = ['SlyText','WordStatistics']
from .SlyText import *
from .WordStatistics import * 
import pretty_errors