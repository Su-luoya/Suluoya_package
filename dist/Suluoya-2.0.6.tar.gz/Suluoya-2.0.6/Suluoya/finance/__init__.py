__name__ = "Suluoya"
__author__ = 'Suluoya'
__all__ = ['SlyFinance']
from .SlyFinance import *
import pretty_errors