__name__ = "Suluoya"
__author__ = 'Suluoya'
__all__ = ['SlyModel']
from .SlyModel import *
import pretty_errors