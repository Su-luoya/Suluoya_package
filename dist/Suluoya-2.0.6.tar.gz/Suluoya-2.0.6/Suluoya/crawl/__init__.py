__name__ = "Suluoya"
__author__ = 'Suluoya'
__all__ = ['SlyCrawl']
from .SlyCrawl import *
from .DownloadNovel import *