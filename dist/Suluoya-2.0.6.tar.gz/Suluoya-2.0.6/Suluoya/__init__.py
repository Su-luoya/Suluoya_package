name = "Suluoya"
author = 'Suluoya'
author_email = '1931960436@qq.com'
qq = '1931960436'
__all__ = ['sly']
from .sly import *
def welcome():
    print('Welcome to use Suluoya!')
from pprint import pprint as print
import pretty_errors


